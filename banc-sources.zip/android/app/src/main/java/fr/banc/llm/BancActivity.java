package fr.banc.llm;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Locale;

/** Banc d'essai minimal : mesurer un petit modèle de langage sur ce téléphone. */
public class BancActivity extends Activity {

    private static final String[][] MODELES = {
        {"LFM2-350M Q4_K_M", "https://huggingface.co/LiquidAI/LFM2-350M-GGUF/resolve/main/LFM2-350M-Q4_K_M.gguf"},
        {"LFM2-350M Q4_0", "https://huggingface.co/LiquidAI/LFM2-350M-GGUF/resolve/main/LFM2-350M-Q4_0.gguf"},
        {"Qwen3-0.6B Q4_K_M", "https://huggingface.co/unsloth/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q4_K_M.gguf"},
        {"Qwen3-0.6B Q8_0", "https://huggingface.co/Qwen/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q8_0.gguf"},
    };
    private static final int[] CONTEXTES = {512, 768, 1024};
    private static final int[] LIMITES = {64, 128, 256};
    private static final int[] FILS = {1, 2, 3, 4};

    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;

    private TextView texteInfos, texteFichier, texteTelechargement, texteModele, texteReponse, texteMesures, texteJournal, texteAlerte;
    private EditText champUrl, champSysteme, champMessage;
    private RadioGroup groupeModeles, groupeContexte, groupeLimite, groupeFils;
    private CheckBox caseSansReflexion;
    private Button boutonTelecharger, boutonAnnulerTel, boutonSupprimer, boutonCharger, boutonDecharger, boutonEnvoyer, boutonArreter;

    private volatile boolean annulerTelechargement = false;
    private volatile boolean occupe = false;
    private volatile long modele = 0;
    private String nomModeleCharge = "";
    private final StringBuilder rapport = new StringBuilder();

    // ------------------------------------------------------------------ interface

    @Override
    protected void onCreate(Bundle etat) {
        super.onCreate(etat);
        prefs = getSharedPreferences("banc", Context.MODE_PRIVATE);

        ScrollView defilement = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int m = dp(12);
        col.setPadding(m, m, m, m);
        defilement.addView(col);
        setContentView(defilement);

        titre(col, "Banc d'essai — modèle local");
        texteAlerte = texte(col, "");
        texteAlerte.setTextColor(Color.rgb(180, 30, 30));
        texteInfos = texte(col, "");
        texteInfos.setTypeface(Typeface.MONOSPACE);
        texteInfos.setTextSize(11);

        titre(col, "1. Modèle à télécharger");
        groupeModeles = new RadioGroup(this);
        for (int i = 0; i < MODELES.length; i++) {
            RadioButton r = new RadioButton(this);
            r.setId(1000 + i);
            r.setText(MODELES[i][0]);
            groupeModeles.addView(r);
        }
        col.addView(groupeModeles);
        champUrl = new EditText(this);
        champUrl.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        champUrl.setTextSize(12);
        col.addView(champUrl);
        groupeModeles.setOnCheckedChangeListener((g, id) -> {
            int i = id - 1000;
            if (i >= 0 && i < MODELES.length) champUrl.setText(MODELES[i][1]);
            majFichier();
        });
        texteFichier = texte(col, "");
        LinearLayout ligneTel = ligne(col);
        boutonTelecharger = bouton(ligneTel, "Télécharger", v -> telecharger());
        boutonAnnulerTel = bouton(ligneTel, "Annuler", v -> annulerTelechargement = true);
        boutonSupprimer = bouton(ligneTel, "Supprimer", v -> supprimer());
        texteTelechargement = texte(col, "");

        titre(col, "2. Réglages");
        texte(col, "Contexte (jetons) :");
        groupeContexte = choix(col, CONTEXTES, 0);
        texte(col, "Longueur maximale de la réponse (jetons) :");
        groupeLimite = choix(col, LIMITES, 1);
        texte(col, "Fils de calcul :");
        groupeFils = choix(col, FILS, 3);

        titre(col, "3. Charger le modèle");
        LinearLayout ligneCharge = ligne(col);
        boutonCharger = bouton(ligneCharge, "Charger", v -> charger());
        boutonDecharger = bouton(ligneCharge, "Décharger", v -> decharger());
        texteModele = texte(col, "Aucun modèle chargé.");

        titre(col, "4. Message");
        texte(col, "Consigne système (facultative) :");
        champSysteme = new EditText(this);
        champSysteme.setText("Tu es un assistant utile. Réponds en français, en quelques phrases.");
        champSysteme.setTextSize(13);
        col.addView(champSysteme);
        caseSansReflexion = new CheckBox(this);
        caseSansReflexion.setText("Qwen3 : sans réflexion (ajoute /no_think)");
        col.addView(caseSansReflexion);
        champMessage = new EditText(this);
        champMessage.setHint("Écris ton message");
        champMessage.setText("Bonjour ! Peux-tu me donner trois idées de repas simples ?");
        champMessage.setMinLines(2);
        col.addView(champMessage);
        LinearLayout ligneEnvoi = ligne(col);
        boutonEnvoyer = bouton(ligneEnvoi, "Envoyer", v -> envoyer());
        boutonArreter = bouton(ligneEnvoi, "Arrêter", v -> Natif.arreter());

        titre(col, "Réponse");
        texteReponse = texte(col, "");
        texteReponse.setTextSize(15);

        titre(col, "Mesures");
        texteMesures = texte(col, "");
        texteMesures.setTypeface(Typeface.MONOSPACE);
        texteMesures.setTextSize(12);
        LinearLayout ligneRapport = ligne(col);
        bouton(ligneRapport, "Copier le rapport", v -> copierRapport());
        bouton(ligneRapport, "Journal", v -> majJournal());
        texteJournal = texte(col, "");
        texteJournal.setTypeface(Typeface.MONOSPACE);
        texteJournal.setTextSize(10);

        // Un essai précédent s'est-il arrêté brutalement ?
        String etape = prefs.getString("etape", "");
        if (!etape.isEmpty()) {
            texteAlerte.setText("⚠ Le dernier essai s'est arrêté brutalement pendant : " + etape
                + "\n(probable manque de mémoire ou instruction non prise en charge)");
            ajouterRapport("ARRÊT BRUTAL précédent pendant : " + etape);
            prefs.edit().putString("etape", "").apply();
        }

        groupeModeles.check(1000 + prefs.getInt("modele", 0));
        afficherInfos();
        majBoutons();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView titre(LinearLayout parent, String s) {
        TextView t = texte(parent, s);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(17);
        t.setPadding(0, dp(14), 0, dp(4));
        return t;
    }

    private TextView texte(LinearLayout parent, String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(14);
        t.setTextIsSelectable(true);
        parent.addView(t);
        return t;
    }

    private LinearLayout ligne(LinearLayout parent) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(l);
        return l;
    }

    private Button bouton(LinearLayout parent, String s, View.OnClickListener action) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setOnClickListener(action);
        parent.addView(b);
        return b;
    }

    private RadioGroup choix(LinearLayout parent, int[] valeurs, int parDefaut) {
        RadioGroup g = new RadioGroup(this);
        g.setOrientation(RadioGroup.HORIZONTAL);
        for (int i = 0; i < valeurs.length; i++) {
            RadioButton r = new RadioButton(this);
            r.setId(2000 + valeurs[i] + parent.getChildCount() * 10000);
            r.setText(String.valueOf(valeurs[i]));
            r.setTag(valeurs[i]);
            g.addView(r);
            if (i == parDefaut) r.setChecked(true);
        }
        parent.addView(g);
        return g;
    }

    private int valeur(RadioGroup g, int secours) {
        View v = g.findViewById(g.getCheckedRadioButtonId());
        if (v != null && v.getTag() instanceof Integer) return (Integer) v.getTag();
        return secours;
    }

    private void majBoutons() {
        boolean fichier = fichierModele().exists();
        boutonTelecharger.setEnabled(!occupe);
        boutonAnnulerTel.setEnabled(occupe);
        boutonSupprimer.setEnabled(!occupe && fichier && modele == 0);
        boutonCharger.setEnabled(!occupe && fichier && modele == 0 && Natif.erreurChargement == null);
        boutonDecharger.setEnabled(!occupe && modele != 0);
        boutonEnvoyer.setEnabled(!occupe && modele != 0);
        boutonArreter.setEnabled(occupe && modele != 0);
    }

    // ------------------------------------------------------------------ informations

    private void afficherInfos() {
        StringBuilder s = new StringBuilder();
        s.append("Appareil : ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
         .append(" — Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        s.append("Matériel : ").append(Build.HARDWARE).append(" — os.arch : ").append(System.getProperty("os.arch")).append('\n');
        s.append("ABI prises en charge : ").append(Arrays.toString(Build.SUPPORTED_ABIS)).append('\n');
        s.append("ABI 64 bits : ").append(Arrays.toString(Build.SUPPORTED_64_BIT_ABIS)).append('\n');
        s.append(memoire()).append('\n');
        if (Natif.erreurChargement != null) {
            s.append("BIBLIOTHÈQUE NATIVE NON CHARGÉE : ").append(Natif.erreurChargement);
        } else {
            try {
                s.append("llama.cpp : ").append(Natif.infosSysteme());
            } catch (Throwable t) {
                s.append("llama.cpp : erreur ").append(t);
            }
        }
        texteInfos.setText(s.toString());
        ajouterRapport(s.toString());
    }

    private String memoire() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return String.format(Locale.FRANCE,
            "Mémoire : appli %s (pic %s) — téléphone libre %d Mo / %d Mo%s",
            lireStatus("VmRSS"), lireStatus("VmHWM"),
            mi.availMem / (1024 * 1024), mi.totalMem / (1024 * 1024),
            mi.lowMemory ? " — MÉMOIRE BASSE" : "");
    }

    private static String lireStatus(String cle) {
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/self/status"))) {
            String l;
            while ((l = r.readLine()) != null) {
                if (l.startsWith(cle + ":")) {
                    String[] p = l.substring(cle.length() + 1).trim().split("\\s+");
                    long ko = Long.parseLong(p[0]);
                    return (ko / 1024) + " Mo";
                }
            }
        } catch (Exception e) {
            return "?";
        }
        return "?";
    }

    private void ajouterRapport(String s) {
        rapport.append(s).append('\n');
    }

    private void copierRapport() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("rapport", rapport.toString()));
        texteAlerte.setText("Rapport copié dans le presse-papiers.");
    }

    private void majJournal() {
        try {
            texteJournal.setText(Natif.journal());
        } catch (Throwable t) {
            texteJournal.setText("Journal indisponible : " + t);
        }
    }

    private void etape(String s) {
        prefs.edit().putString("etape", s).commit();
    }

    // ------------------------------------------------------------------ fichier du modèle

    private File dossierModeles() {
        File d = getExternalFilesDir("modeles");
        if (d == null) d = new File(getFilesDir(), "modeles");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private String nomFichier() {
        String url = champUrl.getText().toString().trim();
        int q = url.indexOf('?');
        if (q >= 0) url = url.substring(0, q);
        String nom = url.substring(url.lastIndexOf('/') + 1);
        return nom.isEmpty() ? "modele.gguf" : nom;
    }

    private File fichierModele() {
        return new File(dossierModeles(), nomFichier());
    }

    private void majFichier() {
        File f = fichierModele();
        File partiel = new File(f.getPath() + ".part");
        if (f.exists()) {
            texteFichier.setText("Fichier présent : " + f.getName() + " (" + (f.length() / (1024 * 1024)) + " Mo)");
        } else if (partiel.exists()) {
            texteFichier.setText("Téléchargement interrompu : " + (partiel.length() / (1024 * 1024)) + " Mo déjà reçus (reprise possible)");
        } else {
            texteFichier.setText("Fichier absent : " + f.getName());
        }
        if (boutonCharger != null) majBoutons();
        int i = groupeModeles.getCheckedRadioButtonId() - 1000;
        if (prefs != null && i >= 0) prefs.edit().putInt("modele", i).apply();
    }

    private void supprimer() {
        File f = fichierModele();
        boolean ok = f.delete();
        new File(f.getPath() + ".part").delete();
        texteTelechargement.setText(ok ? "Modèle supprimé." : "Rien à supprimer.");
        majFichier();
    }

    private void telecharger() {
        final String adresse = champUrl.getText().toString().trim();
        final File cible = fichierModele();
        if (cible.exists()) {
            texteTelechargement.setText("Déjà téléchargé.");
            return;
        }
        annulerTelechargement = false;
        occupe = true;
        majBoutons();
        new Thread(() -> {
            File partiel = new File(cible.getPath() + ".part");
            String resultat;
            HttpURLConnection c = null;
            try {
                long deja = partiel.exists() ? partiel.length() : 0;
                c = (HttpURLConnection) new URL(adresse).openConnection();
                c.setInstanceFollowRedirects(true);
                c.setConnectTimeout(20000);
                c.setReadTimeout(30000);
                c.setRequestProperty("User-Agent", "banc-llm/1.0");
                if (deja > 0) c.setRequestProperty("Range", "bytes=" + deja + "-");
                int code = c.getResponseCode();
                boolean reprise = code == 206;
                if (code != 200 && code != 206) throw new Exception("réponse HTTP " + code);
                if (!reprise) deja = 0;
                long total = c.getContentLengthLong();
                if (total > 0) total += deja;
                try (InputStream in = c.getInputStream();
                     OutputStream out = new FileOutputStream(partiel, reprise)) {
                    byte[] tampon = new byte[64 * 1024];
                    long recu = deja;
                    long dernier = 0;
                    long debut = SystemClock.elapsedRealtime();
                    int n;
                    while ((n = in.read(tampon)) > 0) {
                        if (annulerTelechargement) throw new Exception("annulé (reprise possible)");
                        out.write(tampon, 0, n);
                        recu += n;
                        long t = SystemClock.elapsedRealtime();
                        if (t - dernier > 500) {
                            dernier = t;
                            final long r = recu, tt = total;
                            final double vitesse = (r - 0.0) / Math.max(1, t - debut) * 1000 / (1024 * 1024);
                            ui.post(() -> texteTelechargement.setText(String.format(Locale.FRANCE,
                                "Téléchargement : %d / %s Mo (%.1f Mo/s)",
                                r / (1024 * 1024), tt > 0 ? String.valueOf(tt / (1024 * 1024)) : "?", vitesse)));
                        }
                    }
                }
                if (!partiel.renameTo(cible)) throw new Exception("impossible de renommer le fichier");
                resultat = "Téléchargement terminé : " + (cible.length() / (1024 * 1024)) + " Mo.";
            } catch (Exception e) {
                resultat = "Téléchargement interrompu : " + e.getMessage();
            } finally {
                if (c != null) c.disconnect();
            }
            final String fin = resultat;
            ui.post(() -> {
                occupe = false;
                texteTelechargement.setText(fin);
                ajouterRapport(fin);
                majFichier();
                majBoutons();
            });
        }, "telechargement").start();
    }

    // ------------------------------------------------------------------ modèle

    private void charger() {
        final File f = fichierModele();
        occupe = true;
        majBoutons();
        texteModele.setText("Chargement de " + f.getName() + "…");
        final String avant = memoire();
        new Thread(() -> {
            etape("chargement de " + f.getName());
            long t0 = SystemClock.elapsedRealtime();
            long h = 0;
            String desc;
            try {
                h = Natif.charger(f.getAbsolutePath());
                desc = h != 0 ? Natif.description(h) : "ÉCHEC du chargement (voir Journal)";
            } catch (Throwable t) {
                desc = "ERREUR : " + t;
            }
            etape("");
            final long duree = SystemClock.elapsedRealtime() - t0;
            final long handle = h;
            final String d = desc;
            ui.post(() -> {
                modele = handle;
                nomModeleCharge = f.getName();
                occupe = false;
                String s = d + "\nChargé en " + duree + " ms\nAvant : " + avant + "\nAprès : " + memoire();
                texteModele.setText(s);
                ajouterRapport("=== " + f.getName() + " ===\n" + s);
                majBoutons();
            });
        }, "chargement").start();
    }

    private void decharger() {
        if (modele == 0) return;
        Natif.decharger(modele);
        modele = 0;
        texteModele.setText("Modèle déchargé. " + memoire());
        majBoutons();
    }

    private void envoyer() {
        String message = champMessage.getText().toString().trim();
        if (message.isEmpty() || modele == 0) return;
        if (caseSansReflexion.isChecked()) message = message + " /no_think";
        final String msg = message;
        final String systeme = champSysteme.getText().toString().trim();
        final int nCtx = valeur(groupeContexte, 512);
        final int nMax = valeur(groupeLimite, 128);
        final int nFils = valeur(groupeFils, 4);
        final long h = modele;
        occupe = true;
        majBoutons();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        texteReponse.setText("");
        texteMesures.setText("Calcul en cours…");
        final ByteArrayOutputStream recus = new ByteArrayOutputStream();
        final long[] dernierAffichage = {0};
        new Thread(() -> {
            etape("génération (contexte " + nCtx + ", fils " + nFils + ") avec " + nomModeleCharge);
            try {
                Natif.generer(h, systeme, msg, nCtx, nMax, nFils, new Natif.Rappel() {
                    @Override
                    public void morceau(byte[] octets) {
                        synchronized (recus) {
                            recus.write(octets, 0, octets.length);
                        }
                        long t = SystemClock.elapsedRealtime();
                        if (t - dernierAffichage[0] > 150) {
                            dernierAffichage[0] = t;
                            final String texte;
                            synchronized (recus) {
                                texte = new String(recus.toByteArray(), StandardCharsets.UTF_8);
                            }
                            ui.post(() -> texteReponse.setText(texte));
                        }
                    }

                    @Override
                    public void fin(String mesures) {
                        final String texte;
                        synchronized (recus) {
                            texte = new String(recus.toByteArray(), StandardCharsets.UTF_8);
                        }
                        ui.post(() -> {
                            texteReponse.setText(texte);
                            String s = mesures + "\n" + memoire();
                            texteMesures.setText(s);
                            ajouterRapport("--- message ---\n" + msg + "\n--- réponse ---\n" + texte + "\n--- mesures ---\n" + s);
                        });
                    }
                });
            } catch (Throwable t) {
                ui.post(() -> texteMesures.setText("ERREUR : " + t));
            }
            etape("");
            ui.post(() -> {
                occupe = false;
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                majBoutons();
            });
        }, "generation").start();
    }

    @Override
    protected void onDestroy() {
        if (modele != 0 && !occupe) {
            Natif.decharger(modele);
            modele = 0;
        }
        super.onDestroy();
    }
}
