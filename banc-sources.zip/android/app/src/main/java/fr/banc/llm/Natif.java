package fr.banc.llm;

import java.nio.charset.StandardCharsets;

/** Accès à la bibliothèque native (llama.cpp compilé en armeabi-v7a). */
public final class Natif {

    public static String erreurChargement = null;

    static {
        try {
            System.loadLibrary("banc");
        } catch (Throwable t) {
            erreurChargement = t.toString();
        }
    }

    private Natif() { }

    public interface Rappel {
        void morceau(byte[] octets);
        void fin(String mesures);
    }

    public static native String infosSysteme();
    public static native String journal();
    public static native long charger(String chemin);
    public static native String description(long modele);
    public static native void decharger(long modele);
    public static native void arreter();
    public static native void generer(long modele, String systeme, String message,
                                      int nCtx, int nMax, int nFils, Rappel rappel);

    // Utilisés par le code natif pour échanger du texte UTF-8 sans risque.
    public static String decoder(byte[] octets) {
        return new String(octets, StandardCharsets.UTF_8);
    }

    public static byte[] encoder(String texte) {
        return texte == null ? new byte[0] : texte.getBytes(StandardCharsets.UTF_8);
    }
}
