// Banc d'essai llama.cpp pour Android 32 bits (armeabi-v7a).
// Un seul modèle chargé à la fois. Chaque message utilise un contexte neuf
// (pas de mémoire de conversation : c'est un banc de mesure).

#include <jni.h>
#include <android/log.h>

#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <deque>
#include <mutex>
#include <string>
#include <vector>

#include "llama.h"

#define TAG "banc-llm"

static std::atomic<bool> g_arret{false};
static std::mutex g_journal_mutex;
static std::deque<std::string> g_journal;
static bool g_backend_pret = false;

static void noter(const std::string & ligne) {
    std::lock_guard<std::mutex> verrou(g_journal_mutex);
    g_journal.push_back(ligne);
    while (g_journal.size() > 40) g_journal.pop_front();
}

static void rappel_journal(enum ggml_log_level niveau, const char * texte, void * /*donnees*/) {
    if (texte == nullptr) return;
    int prio = ANDROID_LOG_INFO;
    if (niveau == GGML_LOG_LEVEL_ERROR) prio = ANDROID_LOG_ERROR;
    else if (niveau == GGML_LOG_LEVEL_WARN) prio = ANDROID_LOG_WARN;
    else if (niveau == GGML_LOG_LEVEL_DEBUG) return;
    __android_log_print(prio, TAG, "%s", texte);
    std::string t(texte);
    while (!t.empty() && (t.back() == '\n' || t.back() == '\r')) t.pop_back();
    if (!t.empty()) noter(t);
}

static void initialiser() {
    if (g_backend_pret) return;
    llama_log_set(rappel_journal, nullptr);
    llama_backend_init();
    g_backend_pret = true;
}

static double maintenant_ms() {
    using namespace std::chrono;
    return duration<double, std::milli>(steady_clock::now().time_since_epoch()).count();
}

static jstring vers_java(JNIEnv * env, const std::string & s) {
    // Texte ASCII/UTF-8 sûr : on passe par un tableau d'octets décodé côté Java.
    jbyteArray octets = env->NewByteArray((jsize) s.size());
    env->SetByteArrayRegion(octets, 0, (jsize) s.size(), (const jbyte *) s.data());
    jclass cls = env->FindClass("fr/banc/llm/Natif");
    jmethodID m = env->GetStaticMethodID(cls, "decoder", "([B)Ljava/lang/String;");
    jstring res = (jstring) env->CallStaticObjectMethod(cls, m, octets);
    env->DeleteLocalRef(octets);
    env->DeleteLocalRef(cls);
    return res;
}

static std::string depuis_java(JNIEnv * env, jstring js) {
    if (js == nullptr) return std::string();
    jclass cls = env->FindClass("fr/banc/llm/Natif");
    jmethodID m = env->GetStaticMethodID(cls, "encoder", "(Ljava/lang/String;)[B");
    jbyteArray octets = (jbyteArray) env->CallStaticObjectMethod(cls, m, js);
    jsize n = env->GetArrayLength(octets);
    std::string s((size_t) n, '\0');
    if (n > 0) env->GetByteArrayRegion(octets, 0, n, (jbyte *) &s[0]);
    env->DeleteLocalRef(octets);
    env->DeleteLocalRef(cls);
    return s;
}

extern "C" {

JNIEXPORT jstring JNICALL
Java_fr_banc_llm_Natif_infosSysteme(JNIEnv * env, jclass) {
    initialiser();
    std::string s = llama_print_system_info();
#if defined(__aarch64__)
    s += " | compilé pour : arm64-v8a";
#elif defined(__arm__)
    s += " | compilé pour : armeabi-v7a";
#else
    s += " | compilé pour : autre";
#endif
#if defined(__ARM_NEON)
    s += " | NEON à la compilation : oui";
#else
    s += " | NEON à la compilation : non";
#endif
    return vers_java(env, s);
}

JNIEXPORT jstring JNICALL
Java_fr_banc_llm_Natif_journal(JNIEnv * env, jclass) {
    std::string s;
    {
        std::lock_guard<std::mutex> verrou(g_journal_mutex);
        for (const auto & l : g_journal) { s += l; s += '\n'; }
    }
    return vers_java(env, s);
}

JNIEXPORT jlong JNICALL
Java_fr_banc_llm_Natif_charger(JNIEnv * env, jclass, jstring jchemin) {
    initialiser();
    std::string chemin = depuis_java(env, jchemin);
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.use_mmap = true;
    mp.use_mlock = false;
    llama_model * modele = llama_model_load_from_file(chemin.c_str(), mp);
    if (modele == nullptr) {
        noter("ÉCHEC du chargement du modèle : " + chemin);
        return 0;
    }
    return (jlong) (intptr_t) modele;
}

JNIEXPORT jstring JNICALL
Java_fr_banc_llm_Natif_description(JNIEnv * env, jclass, jlong jmodele) {
    llama_model * modele = (llama_model *) (intptr_t) jmodele;
    if (modele == nullptr) return vers_java(env, "aucun modèle");
    char desc[256];
    desc[0] = '\0';
    llama_model_desc(modele, desc, sizeof(desc));
    char ligne[512];
    snprintf(ligne, sizeof(ligne), "%s — %.1f M paramètres — %.0f Mo — contexte d'entraînement %d",
             desc,
             (double) llama_model_n_params(modele) / 1e6,
             (double) llama_model_size(modele) / (1024.0 * 1024.0),
             (int) llama_model_n_ctx_train(modele));
    return vers_java(env, ligne);
}

JNIEXPORT void JNICALL
Java_fr_banc_llm_Natif_decharger(JNIEnv *, jclass, jlong jmodele) {
    llama_model * modele = (llama_model *) (intptr_t) jmodele;
    if (modele != nullptr) llama_model_free(modele);
}

JNIEXPORT void JNICALL
Java_fr_banc_llm_Natif_arreter(JNIEnv *, jclass) {
    g_arret.store(true);
}

// Génère une réponse. rappel : objet Java avec morceau(byte[]) et fin(String mesures).
JNIEXPORT void JNICALL
Java_fr_banc_llm_Natif_generer(JNIEnv * env, jclass, jlong jmodele, jstring jsysteme, jstring jmessage,
                               jint nCtx, jint nMax, jint nFils, jobject rappel) {
    g_arret.store(false);
    jclass cls = env->GetObjectClass(rappel);
    jmethodID surMorceau = env->GetMethodID(cls, "morceau", "([B)V");
    jmethodID surFin = env->GetMethodID(cls, "fin", "(Ljava/lang/String;)V");

    auto finir = [&](const std::string & mesures) {
        jstring js = vers_java(env, mesures);
        env->CallVoidMethod(rappel, surFin, js);
        env->DeleteLocalRef(js);
    };

    llama_model * modele = (llama_model *) (intptr_t) jmodele;
    if (modele == nullptr) { finir("ERREUR : aucun modèle chargé"); return; }
    const llama_vocab * vocab = llama_model_get_vocab(modele);

    double t0 = maintenant_ms();

    // 1) Contexte neuf
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t) nCtx;
    cp.n_batch = (uint32_t) nCtx;
    cp.n_ubatch = (uint32_t) (nCtx < 512 ? nCtx : 512);
    cp.n_threads = nFils;
    cp.n_threads_batch = nFils;
    cp.no_perf = false;
    llama_context * ctx = llama_init_from_model(modele, cp);
    if (ctx == nullptr) { finir("ERREUR : impossible de créer le contexte (mémoire ?)"); return; }
    double t_ctx = maintenant_ms();

    // 2) Mise en forme de la conversation (gabarit du modèle, sinon ChatML)
    std::string systeme = depuis_java(env, jsysteme);
    std::string message = depuis_java(env, jmessage);
    std::vector<llama_chat_message> msgs;
    if (!systeme.empty()) msgs.push_back({"system", systeme.c_str()});
    msgs.push_back({"user", message.c_str()});
    std::string invite;
    const char * gabarit = llama_model_chat_template(modele, nullptr);
    if (gabarit != nullptr) {
        std::vector<char> tampon(systeme.size() + message.size() + 1024);
        int32_t n = llama_chat_apply_template(gabarit, msgs.data(), msgs.size(), true, tampon.data(), (int32_t) tampon.size());
        if (n > (int32_t) tampon.size()) {
            tampon.resize((size_t) n + 1);
            n = llama_chat_apply_template(gabarit, msgs.data(), msgs.size(), true, tampon.data(), (int32_t) tampon.size());
        }
        if (n > 0) invite.assign(tampon.data(), (size_t) n);
    }
    std::string gabarit_utilise = invite.empty() ? "ChatML (secours)" : "gabarit du modèle";
    if (invite.empty()) {
        if (!systeme.empty()) invite += "<|im_start|>system\n" + systeme + "<|im_end|>\n";
        invite += "<|im_start|>user\n" + message + "<|im_end|>\n<|im_start|>assistant\n";
    }

    // 3) Découpage en jetons
    int32_t nJetons = -llama_tokenize(vocab, invite.c_str(), (int32_t) invite.size(), nullptr, 0, true, true);
    if (nJetons <= 0) { llama_free(ctx); finir("ERREUR : découpage en jetons impossible"); return; }
    std::vector<llama_token> jetons((size_t) nJetons);
    if (llama_tokenize(vocab, invite.c_str(), (int32_t) invite.size(), jetons.data(), nJetons, true, true) < 0) {
        llama_free(ctx); finir("ERREUR : découpage en jetons impossible"); return;
    }
    if (nJetons >= nCtx - 4) {
        llama_free(ctx);
        char m[160];
        snprintf(m, sizeof(m), "ERREUR : message trop long (%d jetons) pour un contexte de %d", nJetons, (int) nCtx);
        finir(m);
        return;
    }
    int limite = nMax;
    if (nJetons + limite > nCtx) limite = nCtx - nJetons;

    // 4) Lecture de l'invite
    double t_lecture0 = maintenant_ms();
    if (llama_decode(ctx, llama_batch_get_one(jetons.data(), nJetons)) != 0) {
        llama_free(ctx); finir("ERREUR : échec de la lecture de l'invite"); return;
    }
    double t_lecture1 = maintenant_ms();

    // 5) Échantillonnage (réglages conseillés pour les petits modèles)
    llama_sampler * ech = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(ech, llama_sampler_init_penalties(64, 1.05f, 0.0f, 0.0f));
    llama_sampler_chain_add(ech, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(ech, llama_sampler_init_min_p(0.15f, 1));
    llama_sampler_chain_add(ech, llama_sampler_init_temp(0.3f));
    llama_sampler_chain_add(ech, llama_sampler_init_dist(1234));

    // 6) Écriture en continu
    int produits = 0;
    double t_premier = -1;
    std::string raison = "limite de longueur atteinte";
    char morceau[512];
    for (int i = 0; i < limite; i++) {
        if (g_arret.load()) { raison = "arrêt demandé"; break; }
        llama_token id = llama_sampler_sample(ech, ctx, -1);
        if (llama_vocab_is_eog(vocab, id)) { raison = "fin naturelle"; break; }
        if (t_premier < 0) t_premier = maintenant_ms();
        produits++;
        int32_t n = llama_token_to_piece(vocab, id, morceau, sizeof(morceau), 0, false);
        if (n > 0) {
            jbyteArray octets = env->NewByteArray(n);
            env->SetByteArrayRegion(octets, 0, n, (const jbyte *) morceau);
            env->CallVoidMethod(rappel, surMorceau, octets);
            env->DeleteLocalRef(octets);
        }
        llama_token suivant = id;
        if (llama_decode(ctx, llama_batch_get_one(&suivant, 1)) != 0) { raison = "échec d'écriture"; break; }
    }
    double t_fin = maintenant_ms();
    llama_sampler_free(ech);
    llama_free(ctx);

    double lecture_s = (t_lecture1 - t_lecture0) / 1000.0;
    double ecriture_s = t_premier < 0 ? 0 : (t_fin - t_premier) / 1000.0;
    char mesures[1024];
    snprintf(mesures, sizeof(mesures),
             "Jetons de l'invite : %d (%s)\n"
             "Préparation du contexte : %.0f ms\n"
             "Lecture de l'invite : %.2f s → %.1f jetons/s\n"
             "Temps avant le premier mot : %.2f s\n"
             "Jetons écrits : %d en %.2f s → %.2f jetons/s\n"
             "Fin : %s\n"
             "Réglages : contexte %d, limite %d, fils %d",
             nJetons, gabarit_utilise.c_str(),
             t_ctx - t0,
             lecture_s, lecture_s > 0 ? nJetons / lecture_s : 0.0,
             t_premier < 0 ? 0.0 : (t_premier - t0) / 1000.0,
             produits, ecriture_s, ecriture_s > 0 ? produits / ecriture_s : 0.0,
             raison.c_str(),
             (int) nCtx, (int) nMax, (int) nFils);
    finir(mesures);
}

} // extern "C"
